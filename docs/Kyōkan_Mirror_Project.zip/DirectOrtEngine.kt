package com.kokoro.reader

import android.content.Context
import android.util.Log
import ai.onnxruntime.*
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer

/**
 * DirectOrtEngine — Direct ONNX Runtime inference for tensor-level control.
 *
 * This bypasses sherpa-onnx's high-level API to give us direct access to
 * model inputs and outputs. We can manipulate the style vector, scales,
 * and any other tensor before passing it to the model.
 *
 * IMPORTANT: This uses the same libonnxruntime.so that sherpa-onnx uses.
 * The Xiaomi HWUI crash protection (running in :tts process) still applies.
 * If direct ORT fails, SherpaEngine's existing cascade catches it.
 *
 * Dependencies: Add to build.gradle:
 *   implementation 'com.microsoft.onnxruntime:onnxruntime-android:1.17.0'
 *
 * NOTE: If sherpa_onnx.aar already bundles libonnxruntime.so, you may get
 * duplicate native lib errors. In that case, exclude the ORT lib from one:
 *   implementation('com.microsoft.onnxruntime:onnxruntime-android:1.17.0') {
 *       exclude group: 'com.microsoft.onnxruntime', module: 'onnxruntime-android'
 *   }
 * and use ORT from sherpa's bundled library instead. See INTEGRATION_NOTES below.
 */
class DirectOrtEngine(private val context: Context) {

    companion object {
        private const val TAG = "DirectOrtEngine"
    }

    // ─── State ──────────────────────────────────────────────────────────

    private var ortEnv: OrtEnvironment? = null
    private var kokoroSession: OrtSession? = null
    private var piperSession: OrtSession? = null

    // Kokoro voices data (loaded from voices.bin)
    private var voicesData: FloatArray? = null
    private var voiceCount: Int = 0
    private var tokensPerVoice: Int = 0  // usually 510 or 512

    // Engine state
    @Volatile var isKokoroReady = false
        private set
    @Volatile var isPiperReady = false
        private set

    // ─── Initialization ─────────────────────────────────────────────────

    /**
     * Initialize the ORT environment and load models.
     * Call this from the :tts process thread, AFTER SherpaEngine's crash-loop check.
     *
     * @param kokoroModelPath Path to kokoro-v1.0.onnx on filesystem
     * @param voicesBinPath Path to voices-v1.0.bin
     * @param piperModelPath Path to Piper .onnx model (optional)
     * @param numThreads ORT inference threads (from device profiling)
     */
    fun initialize(
        kokoroModelPath: String,
        voicesBinPath: String,
        piperModelPath: String? = null,
        numThreads: Int = 2
    ): Boolean {
        return try {
            ortEnv = OrtEnvironment.getEnvironment()
            val sessionOptions = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(numThreads)
                setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
                // Use CPU provider — NNAPI can cause issues on some devices
                // Add NNAPI only if device profiling confirms it works
            }

            // Load Kokoro
            if (File(kokoroModelPath).exists()) {
                kokoroSession = ortEnv!!.createSession(kokoroModelPath, sessionOptions)
                loadVoices(voicesBinPath)
                isKokoroReady = true
                Log.i(TAG, "Kokoro loaded via direct ORT")

                // Validate inputs match expected interface
                validateKokoroInterface()
            }

            // Load Piper
            if (piperModelPath != null && File(piperModelPath).exists()) {
                piperSession = ortEnv!!.createSession(piperModelPath, sessionOptions)
                isPiperReady = true
                Log.i(TAG, "Piper loaded via direct ORT")
            }

            true
        } catch (e: Exception) {
            Log.e(TAG, "Direct ORT init failed: ${e.message}", e)
            cleanup()
            false
        }
    }

    private fun loadVoices(voicesBinPath: String) {
        val file = File(voicesBinPath)
        if (!file.exists()) {
            Log.e(TAG, "voices.bin not found at $voicesBinPath")
            return
        }

        // Read raw float32 data
        val bytes = file.readBytes()
        voicesData = FloatArray(bytes.size / 4)
        java.nio.ByteBuffer.wrap(bytes)
            .order(java.nio.ByteOrder.LITTLE_ENDIAN)
            .asFloatBuffer()
            .get(voicesData!!)

        // Detect structure: total_floats / 256 = total_vectors
        // total_vectors / num_voices = tokens_per_voice
        val totalVectors = voicesData!!.size / 256
        // Try common voice counts from Kokoro releases
        for (numVoices in listOf(26, 54, 108)) {
            if (totalVectors % numVoices == 0) {
                voiceCount = numVoices
                tokensPerVoice = totalVectors / numVoices
                break
            }
        }
        if (voiceCount == 0) {
            // Fallback: assume 512 tokens per voice
            tokensPerVoice = 512
            voiceCount = totalVectors / tokensPerVoice
        }

        Log.i(TAG, "Loaded voices: $voiceCount voices, $tokensPerVoice token variants each")
    }

    private fun validateKokoroInterface() {
        val session = kokoroSession ?: return
        val inputNames = session.inputNames.toList()
        val expectedInputs = listOf("input_ids", "style", "speed")

        Log.i(TAG, "Kokoro inputs: $inputNames")
        for (name in expectedInputs) {
            if (name !in inputNames) {
                Log.w(TAG, "Expected input '$name' not found! Available: $inputNames")
                Log.w(TAG, "Run inspect_graph.py to get actual tensor names")
            }
        }

        session.outputNames.toList().let { outputs ->
            Log.i(TAG, "Kokoro outputs: $outputs")
        }
    }

    // ─── Kokoro Synthesis (with style sculpting) ────────────────────────

    /**
     * Synthesize with Kokoro using a pre-sculpted style vector.
     *
     * @param inputIds Phoneme/token IDs (0-padded, from tokenizer)
     * @param sculptedStyle 256-dim style vector from StyleSculptor
     * @param speed Speed multiplier
     * @return Pair<FloatArray, Int> of (PCM samples, sample rate) or null
     */
    fun synthesizeKokoro(
        inputIds: LongArray,
        sculptedStyle: FloatArray,
        speed: Float = 1.0f
    ): Pair<FloatArray, Int>? {
        val session = kokoroSession ?: return null
        val env = ortEnv ?: return null

        return try {
            // Create input tensors
            val inputIdsTensor = OnnxTensor.createTensor(
                env,
                LongBuffer.wrap(inputIds),
                longArrayOf(1, inputIds.size.toLong())
            )

            val styleTensor = OnnxTensor.createTensor(
                env,
                FloatBuffer.wrap(sculptedStyle),
                longArrayOf(1, 256)
            )

            val speedTensor = OnnxTensor.createTensor(
                env,
                FloatBuffer.wrap(floatArrayOf(speed)),
                longArrayOf(1)
            )

            val inputs = mapOf(
                "input_ids" to inputIdsTensor,
                "style" to styleTensor,
                "speed" to speedTensor,
            )

            // Run inference
            val results = session.run(inputs)

            // Extract waveform — shape is [1, 1, samples] or [1, samples]
            val outputTensor = results[0] as OnnxTensor
            val outputShape = outputTensor.info.shape
            val rawData = outputTensor.floatBuffer

            val samples = FloatArray(rawData.remaining())
            rawData.get(samples)

            // Cleanup
            inputIdsTensor.close()
            styleTensor.close()
            speedTensor.close()
            results.close()

            Pair(samples, 24000)  // Kokoro outputs at 24kHz
        } catch (e: Exception) {
            Log.e(TAG, "Kokoro synthesis failed: ${e.message}", e)
            null
        }
    }

    // ─── Piper Synthesis (with mapped scales) ───────────────────────────

    /**
     * Synthesize with Piper using mapped scale parameters.
     *
     * @param phonemeIds Phoneme IDs from eSpeak/phonemizer
     * @param scales [noise_scale, length_scale, noise_w] from ScaleMapper
     * @param speakerId Speaker ID for multi-speaker models (-1 for single-speaker)
     * @return Pair<FloatArray, Int> of (PCM samples, sample rate) or null
     */
    fun synthesizePiper(
        phonemeIds: LongArray,
        scales: FloatArray,
        speakerId: Long = -1
    ): Pair<FloatArray, Int>? {
        val session = piperSession ?: return null
        val env = ortEnv ?: return null

        return try {
            val inputTensor = OnnxTensor.createTensor(
                env,
                LongBuffer.wrap(phonemeIds),
                longArrayOf(1, phonemeIds.size.toLong())
            )

            val lengthsTensor = OnnxTensor.createTensor(
                env,
                LongBuffer.wrap(longArrayOf(phonemeIds.size.toLong())),
                longArrayOf(1)
            )

            val scalesTensor = OnnxTensor.createTensor(
                env,
                FloatBuffer.wrap(scales),
                longArrayOf(3)
            )

            val inputs = mutableMapOf(
                "input" to inputTensor,
                "input_lengths" to lengthsTensor,
                "scales" to scalesTensor,
            )

            // Add speaker ID only for multi-speaker models
            val sidTensor: OnnxTensor?
            if (speakerId >= 0 && "sid" in session.inputNames) {
                sidTensor = OnnxTensor.createTensor(
                    env,
                    LongBuffer.wrap(longArrayOf(speakerId)),
                    longArrayOf(1)
                )
                inputs["sid"] = sidTensor
            } else {
                sidTensor = null
            }

            val results = session.run(inputs)

            val outputTensor = results[0] as OnnxTensor
            val rawData = outputTensor.floatBuffer
            val samples = FloatArray(rawData.remaining())
            rawData.get(samples)

            // Cleanup
            inputTensor.close()
            lengthsTensor.close()
            scalesTensor.close()
            sidTensor?.close()
            results.close()

            Pair(samples, 22050)  // Piper default sample rate
        } catch (e: Exception) {
            Log.e(TAG, "Piper synthesis failed: ${e.message}", e)
            null
        }
    }

    // ─── Voice Data Access ──────────────────────────────────────────────

    /**
     * Get the raw style vector for a Kokoro voice at a given token count.
     * This is the base vector that StyleSculptor will then modify.
     *
     * @param voiceIndex Which voice (0-based index in voices.bin)
     * @param numTokens Token count of the current utterance
     */
    fun getKokoroStyle(voiceIndex: Int, numTokens: Int): FloatArray? {
        val data = voicesData ?: return null
        if (voiceIndex >= voiceCount) return null

        val tokenIdx = numTokens.coerceIn(0, tokensPerVoice - 1)
        val offset = (voiceIndex * tokensPerVoice + tokenIdx) * 256
        if (offset + 256 > data.size) return null

        return data.copyOfRange(offset, offset + 256)
    }

    /**
     * Get all voice data for analysis (used by StyleSculptor for computing
     * breath directions, energy calibration, etc.)
     */
    fun getAllVoicesData(): FloatArray? = voicesData?.copyOf()
    fun getVoiceCount(): Int = voiceCount
    fun getTokensPerVoice(): Int = tokensPerVoice

    // ─── Lifecycle ──────────────────────────────────────────────────────

    fun cleanup() {
        try {
            kokoroSession?.close()
            piperSession?.close()
            ortEnv?.close()
        } catch (e: Exception) {
            Log.w(TAG, "Cleanup error: ${e.message}")
        }
        kokoroSession = null
        piperSession = null
        ortEnv = null
        isKokoroReady = false
        isPiperReady = false
    }
}

// ─── INTEGRATION NOTES ──────────────────────────────────────────────────
//
// Option 1: Separate ORT dependency (cleanest)
//   Add onnxruntime-android to build.gradle alongside sherpa_onnx.aar.
//   May conflict with sherpa's bundled ORT. Test carefully.
//   If conflict: exclude ORT from one dependency.
//
// Option 2: Use sherpa's ORT via JNI (no extra dependency)
//   Sherpa's aar already includes libonnxruntime.so.
//   Write a thin JNI bridge that calls ORT's C API directly.
//   More work but zero dependency conflict risk.
//
// Option 3: Runtime class loading (advanced)
//   Load onnxruntime classes at runtime from a separate dex.
//   Avoids classpath conflicts entirely.
//   Overkill for this use case.
//
// RECOMMENDED: Start with Option 1. If you get UnsatisfiedLinkError or
// duplicate class errors, fall back to Option 2.
// ────────────────────────────────────────────────────────────────────────
