# Integration Guide — Lego into Kyōkan

## Phase 0: Graph Inspection (30 min)

In your GitHub Codespace:

```bash
pip install onnx onnxruntime numpy

# Get your models — adjust paths to wherever they are in your project
python inspect_graph.py path/to/kokoro-v1.0.onnx --json kokoro_tensors.json
python inspect_graph.py path/to/en_US-amy-low.onnx --json piper_tensors.json
python inspect_graph.py path/to/voices-v1.0.bin

# Compare both models
python inspect_graph.py kokoro-v1.0.onnx en_US-amy-low.onnx --compare
```

**Why this matters:** The tensor names in DirectOrtEngine.kt (`input_ids`, `style`, `speed`) are based on the standard Kokoro v1.0 export. Your actual model might use different names, especially if you're on v0.19 or a custom export. The inspector will tell you the exact names to use.

**What to look for:**
- Confirm Kokoro has 3 inputs: tokens, style vector (256-dim), speed
- Confirm Piper has 3-4 inputs: phonemes, lengths, scales, optional sid
- Note any name differences and update DirectOrtEngine accordingly

## Phase 1: Add ORT Android Dependency (15 min)

In `build.gradle`:

```groovy
dependencies {
    implementation files('libs/sherpa_onnx.aar')  // existing

    // Add direct ORT access
    // Try this first — if it conflicts with sherpa's bundled ORT, see note below
    implementation 'com.microsoft.onnxruntime:onnxruntime-android:1.17.0'
}
```

**If you get duplicate native library errors:**

Sherpa's aar bundles `libonnxruntime.so`. The standalone ORT package also bundles it.
Two options:

A) Use ORT's Java API but exclude its native libs (use sherpa's):
```groovy
implementation('com.microsoft.onnxruntime:onnxruntime-android:1.17.0') {
    // Use the native lib from sherpa_onnx.aar instead
    exclude group: 'com.microsoft.onnxruntime'
}
```
This works only if the ORT Java API version matches sherpa's bundled native lib version.

B) Keep both and let the first-loaded win:
Android's linker loads the first .so it finds. If both are the same version, no conflict.
Check sherpa's ORT version in its build script.

## Phase 2: Wire Up DirectOrtEngine (1 hour)

In `NotificationReaderService.kt` or wherever SherpaEngine is initialized:

```kotlin
// After SherpaEngine.warmUp() succeeds:
private var directOrt: DirectOrtEngine? = null
private var legoSynthesizer: LegoSynthesizer? = null

private fun initializeLego() {
    val ort = DirectOrtEngine(applicationContext)
    val success = ort.initialize(
        kokoroModelPath = "/path/to/extracted/model.onnx",  // same path SherpaEngine uses
        voicesBinPath = "/path/to/extracted/voices.bin",
        piperModelPath = piperModelPath,  // optional
        numThreads = deviceProfile.optimalThreadCount,  // from SherpaEngine's profiling
    )

    if (success) {
        directOrt = ort
        legoSynthesizer = LegoSynthesizer(
            directOrt = ort,
            sherpaFallback = sherpaEngine,
        )
        Log.i(TAG, "Lego pipeline ready")
    } else {
        Log.w(TAG, "Lego init failed, using sherpa-only path")
    }
}
```

## Phase 3: Integrate into AudioPipeline (1 hour)

Find where `AudioPipeline` calls `SherpaEngine.synthesize()`. Currently it's something like:

```kotlin
// BEFORE (in AudioPipeline, simplified):
val (pcm, sampleRate) = sherpaEngine.synthesize(text, modulated.speed) ?: return
val landmarks = phonicAnalyzer.analyze(pcm)
audioDsp.apply(pcm, modulated, landmarks)
```

Replace with:

```kotlin
// AFTER:
val pcm: FloatArray
val sampleRate: Int

val lego = legoSynthesizer
if (lego != null) {
    // Tokenize for Kokoro (you need to add this — see Phase 4)
    val tokenIds = tokenize(text)

    // Add token count to signal for style vector lookup
    val enrichedSignal = signal.copy(tokenCount = tokenIds.size)

    val result = lego.synthesize(tokenIds, modulated, enrichedSignal, activeProfile)
    if (result != null) {
        pcm = result.pcm
        sampleRate = result.sampleRate

        // When using sculpted/mapped path, reduce DSP intensity
        // since the engine already has the emotional parameters baked in
        val dspModulated = if (result.engine == EngineType.KOKORO_SCULPTED) {
            modulated.copy(
                breath = modulated.breath * 0.3f,   // 70% already in style
                jitter = modulated.jitter * 0.2f,    // 80% already in style
                // Keep pitch, trailOff, volume at full — DSP still handles these
            )
        } else {
            modulated
        }

        val landmarks = phonicAnalyzer.analyze(pcm)
        audioDsp.apply(pcm, dspModulated, landmarks)
    } else {
        // Lego failed, use existing path
        val fallback = sherpaEngine.synthesize(text, modulated.speed) ?: return
        pcm = fallback.first
        sampleRate = fallback.second
        val landmarks = phonicAnalyzer.analyze(pcm)
        audioDsp.apply(pcm, modulated, landmarks)
    }
} else {
    // No lego, existing path unchanged
    val fallback = sherpaEngine.synthesize(text, modulated.speed) ?: return
    pcm = fallback.first
    sampleRate = fallback.second
    val landmarks = phonicAnalyzer.analyze(pcm)
    audioDsp.apply(pcm, modulated, landmarks)
}
```

## Phase 4: Tokenization (The Missing Piece)

Kokoro's direct ORT path needs token IDs, not raw text. Sherpa handles this internally.
You need to replicate the tokenization:

1. **Phonemize**: Convert text to IPA phonemes (Kokoro uses misaki/g2p)
2. **Map to IDs**: Convert phonemes to integer token IDs using Kokoro's vocab
3. **Pad**: Add 0 at start and end

For Kokoro v1.0, the token vocab is at:
https://huggingface.co/hexgrad/Kokoro-82M/blob/main/config.json (phoneme_id_map)

Options:
- **Quick**: Call sherpa's internal tokenizer if it exposes one
- **Clean**: Port Kokoro's Python tokenizer to Kotlin
- **Pragmatic**: Use eSpeak-ng (already available for Piper) and map IPA → Kokoro token IDs

The eSpeak path is probably easiest since Piper already uses it and sherpa bundles espeak-ng-data.

## Phase 5: A/B Testing

Add a toggle in ProfilesFragment to switch between:
- **Classic mode**: existing SherpaEngine → full DSP chain
- **Lego mode**: StyleSculptor/ScaleMapper → reduced DSP chain

Test with the same notification text and compare:
- Does the sculpted voice sound more naturally emotional vs DSP-processed?
- Are there artifacts or quality regressions?
- Does it crash on any of your test devices?

## Phase 6: Calibrate the Sculpting

The values in StyleSculptor (breathiness direction, energy scaling factors, emotion blend shifts)
are educated starting points. They need calibration with your actual voice data:

```kotlin
// Run this once to compute the actual breath direction from your voices:
val bellaStyle = directOrt.getKokoroStyle(voiceIndex = 0, numTokens = 50)!!  // af_bella (clear)
val echoStyle = directOrt.getKokoroStyle(voiceIndex = 5, numTokens = 50)!!   // am_echo (breathy)
val breathDir = StyleSculptor.computeBreathDirection(bellaStyle, echoStyle)
// Store this and use it in applyBreathiness() instead of the heuristic
```

---

## File Summary

| File | What it does | Where it goes |
|---|---|---|
| `inspect_graph.py` | Dumps tensor shapes from your models | Run in Codespaces, not in APK |
| `StyleSculptor.kt` | Manipulates Kokoro's 256-dim style vector | `app/src/main/java/com/kokoro/reader/` |
| `ScaleMapper.kt` | Maps emotion → Piper's generative scales | Same directory |
| `DirectOrtEngine.kt` | Direct ORT inference, bypasses sherpa | Same directory |
| `LegoSynthesizer.kt` | Unified pipeline with fallback cascade | Same directory |
| `StubTypes.kt` | DELETE THIS — shows expected interfaces | Your real types already exist |
| `LEGO_ARCHITECTURE.md` | Design doc and reference | Project root or docs/ |

## What Changes in Existing Files

| File | Change |
|---|---|
| `build.gradle` | Add onnxruntime-android dependency |
| `SherpaEngine.kt` | No changes — kept as fallback |
| `AudioPipeline.kt` | Add LegoSynthesizer call before sherpa fallback |
| `NotificationReaderService.kt` | Initialize DirectOrtEngine + LegoSynthesizer |
| `AudioDsp.kt` | No changes — but DSP intensity reduced when lego is active |
| `SignalMap.kt` | Add `tokenCount: Int` field |
| `VoiceModulator.kt` | No changes |
| `ProfilesFragment.kt` | Optional: add lego/classic mode toggle |
