# Kyōkan Lego Architecture — Cracking Open the Engines

## The Problem

Your VoiceModulator produces rich emotional parameters (pitch, speed, breath, stutter, intonation, jitter, volume, trailOff). But only `speed` reaches the engine at synthesis time. Everything else is DSP post-processing on finished PCM — additive effects on a baked waveform.

## What We Now Know

### Kokoro ONNX Interface (StyleTTS2-based, 82M params)

```
INPUTS:
  input_ids : int64  [1, seq_len]     ← phoneme/token IDs (0-padded, max 512)
  style     : float32 [1, 256]        ← voice identity/style embedding vector
  speed     : float32 [1]             ← speaking rate multiplier

OUTPUT:
  waveform  : float32 [1, 1, samples] ← raw PCM at 24000 Hz
```

**The style vector is everything.** It's a 256-dimensional float32 vector loaded from voices.bin. Each voice (af_bella, am_adam, etc.) has multiple style vectors — one per token length — stored as a flat array reshaped to `[-1, 1, 256]`. The vector at index `num_tokens` is selected for that utterance.

This means: **style is not a fixed speaker ID. It's a continuous, manipulable 256-dim space.** You can interpolate, add, subtract, rotate, and blend these vectors before passing them to the model. The model will synthesize a voice that corresponds to wherever you are in that 256-dim space.

### Piper ONNX Interface (VITS-based)

```
INPUTS:
  input         : int64   [batch, phonemes]  ← phoneme IDs
  input_lengths : int64   [batch]            ← phoneme sequence length
  scales        : float32 [3]                ← [noise_scale, length_scale, noise_w]
  sid           : int64   [1]                ← speaker ID (multi-speaker models only)

OUTPUT:
  output        : float32 [batch, 1, time]   ← raw PCM at 22050 Hz
```

**Piper's levers are different.** Instead of a style embedding, Piper exposes:
- `noise_scale` (0.667 default) — controls voice clarity/breathiness at generation time
- `length_scale` (1.0 default) — controls speaking speed (duration of phonemes)
- `noise_w` (0.8 default) — controls variation in phoneme durations (stochastic duration predictor)

These are generative parameters, not post-processing. `noise_scale` literally controls how much random noise feeds into the decoder — higher = breathier/more expressive, lower = cleaner/more robotic. `noise_w` controls how much the duration of each phoneme varies — higher = more natural rhythm, lower = more metronomic.

### Sample Rate Mismatch

- Kokoro: **24000 Hz**
- Piper: **22050 Hz** (most voices)

Not a blocker for the Lego approach since we're not swapping vocoders between them. But important for AudioPipeline/AudioTrack configuration.

---

## The Lego Architecture

Instead of one opaque `synthesize()` call, we expose every manipulation point:

```
                        ┌─────────────────────────────────────────┐
                        │         ModulatedVoice from             │
                        │         VoiceModulator                  │
                        │  (pitch, speed, breath, stutter,        │
                        │   intonation, jitter, volume, trailOff) │
                        └────────┬──────────┬──────────┬──────────┘
                                 │          │          │
                    ┌────────────┘          │          └────────────┐
                    ▼                       ▼                       ▼
          ┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
          │ STYLE SCULPTOR  │    │  DURATION SHAPER  │    │  SCALE MAPPER   │
          │                 │    │                   │    │  (Piper only)   │
          │ Blends/morphs   │    │  Maps emotion to  │    │                 │
          │ Kokoro style    │    │  speed param      │    │  Maps emotion   │
          │ vectors in      │    │  (both engines)   │    │  to noise_scale │
          │ 256-dim space   │    │                   │    │  noise_w        │
          │ based on mood,  │    │                   │    │  length_scale   │
          │ emotion blend,  │    │                   │    │                 │
          │ personality     │    │                   │    │                 │
          └────────┬────────┘    └────────┬──────────┘    └────────┬────────┘
                   │                      │                        │
                   ▼                      ▼                        ▼
          ┌──────────────────────────────────────────────────────────────┐
          │                    ENGINE INTERFACE                          │
          │                                                             │
          │  Kokoro path:  input_ids + sculpted_style + speed → PCM     │
          │  Piper path:   input + lengths + mapped_scales + sid → PCM  │
          │                                                             │
          │  Both via direct ORT InferenceSession (not sherpa wrapper)  │
          └──────────────────────────┬───────────────────────────────────┘
                                     │
                                     ▼
          ┌──────────────────────────────────────────────────────────────┐
          │                 EXISTING DSP CHAIN                          │
          │  (AudioDsp — now handles RESIDUAL effects only)             │
          │                                                             │
          │  What STAYS in DSP:                                         │
          │    - Vocal fry (phrase-end, needs PhonicLandmarks)          │
          │    - Trailing off (needs trajectory signal)                 │
          │    - Soft limiter (always needed)                           │
          │    - Inter-clip crossfade (AudioPipeline level)             │
          │    - Pitch shift (until we can do it pre-synthesis)         │
          │                                                             │
          │  What MOVES OUT of DSP:                                     │
          │    - Breathiness → noise_scale (Piper) / style blend (K)   │
          │    - Jitter → noise_w (Piper) / style vector noise (K)     │
          │    - Intonation range → style interpolation (Kokoro)        │
          │    - Volume/energy → style vector magnitude (Kokoro)        │
          └──────────────────────────────────────────────────────────────┘
```

---

## What Each Emotion Parameter Now Controls (Pre-Synthesis)

| ModulatedVoice param | Old target (DSP) | New target (Kokoro) | New target (Piper) |
|---|---|---|---|
| **pitch** | AudioDsp.pitchShift() resampling | Style vector manipulation (pitch dimension) | Still DSP (Piper has no pitch input) |
| **speed** | SherpaEngine speed param ✓ | speed tensor directly ✓ | length_scale in scales[1] ✓ |
| **breath** | AudioDsp noise layer | Style blend toward breathier voice | noise_scale in scales[0] |
| **stutter** | VoiceTransform text rewrite | Keep as text transform (correct layer) | Keep as text transform |
| **intonation** | VoiceTransform text markers | Style interpolation range | noise_w in scales[2] |
| **jitter** | AudioDsp micro-amplitude variation | Style vector + small random perturbation | noise_w increase |
| **volume** | AudioDsp gain | Style vector energy scaling | Still DSP (no direct input) |
| **trailOff** | AudioDsp phrase-end fade | Keep as DSP (needs PhonicLandmarks) | Keep as DSP |

---

## Implementation Files

1. `inspect_graph.py` — Run in Codespaces to dump all tensor info from your actual models
2. `StyleSculptor.kt` — Kokoro style vector manipulation engine
3. `ScaleMapper.kt` — Piper scales mapping from emotion signals
4. `DirectOrtEngine.kt` — Direct ONNX Runtime inference bypassing sherpa
5. `LegoSynthesizer.kt` — Unified pipeline that replaces `SherpaEngine.synthesize()`

---

## Critical Design Decisions

### Why not split the ONNX graphs?

After examining both models' interfaces, graph splitting is **not necessary** for the initial Lego build. Here's why:

- Kokoro already exposes the style vector as a direct input. You don't need to crack the graph open to manipulate it — it's literally an input tensor. The 256-dim style space IS the internal representation, surfaced as an API.

- Piper already exposes noise_scale, length_scale, noise_w as direct inputs. These are the generative parameters that control voice character at synthesis time.

Graph splitting would be needed if you wanted to, say, take Kokoro's text encoder output and feed it to Piper's decoder. That's a Phase 2 goal. For Phase 1, manipulating the existing input tensors gives you 80% of the expressiveness with 10% of the complexity.

### Fallback strategy

```
Kokoro (direct ORT, style-sculpted) 
  → Kokoro (sherpa, speed-only — existing path)
    → Piper (direct ORT, scale-mapped)
      → Piper (sherpa — existing path)
        → Android System TTS
```

If direct ORT crashes on a device, the existing sherpa path catches it. Your crash recovery system doesn't need to change.
