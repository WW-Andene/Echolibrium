package com.kokoro.reader

import android.util.Log

/**
 * LegoSynthesizer — The unified pipeline that replaces SherpaEngine.synthesize().
 *
 * Instead of:
 *   SherpaEngine.synthesize(text, speed) → PCM  (opaque, speed-only control)
 *
 * We now have:
 *   LegoSynthesizer.synthesize(text, modulated, signal, profile) → PCM
 *     ├─ Kokoro path: style sculpting + direct ORT inference
 *     ├─ Piper path: scale mapping + direct ORT inference
 *     └─ Fallback: existing SherpaEngine path (unchanged)
 *
 * This integrates into AudioPipeline where synthesizeWithFallback() is currently called.
 *
 * THREADING: This runs on AudioPipeline's single synthesis thread.
 * All methods are synchronous and non-reentrant (same as SherpaEngine).
 */
class LegoSynthesizer(
    private val directOrt: DirectOrtEngine,
    private val sherpaFallback: SherpaEngine,  // existing engine as fallback
) {

    companion object {
        private const val TAG = "LegoSynthesizer"
    }

    // ─── Configuration ──────────────────────────────────────────────────

    /** Which voice palette to use as secondary for emotional blending */
    var secondaryVoiceName: String? = null

    /** Kokoro voice index in voices.bin for the active profile */
    var activeKokoroVoiceIndex: Int = 0

    /** Piper speaker ID for multi-speaker models (-1 = single speaker) */
    var activePiperSpeakerId: Long = -1

    /** Whether to try direct ORT before falling back to sherpa */
    var directOrtEnabled: Boolean = true

    // Pre-loaded secondary palette for blending
    private var secondaryPalette: StyleSculptor.VoicePalette? = null

    // ─── Main Synthesis Entry Point ─────────────────────────────────────

    /**
     * Synthesize speech with full emotional control.
     *
     * This replaces the call to SherpaEngine.synthesizeWithFallback() in AudioPipeline.
     *
     * @param tokenIds Phoneme/token IDs (already tokenized by the existing pipeline)
     * @param modulated Emotional modulation from VoiceModulator
     * @param signal Signal map from SignalExtractor
     * @param profile Active voice profile
     * @return SynthResult with PCM data and sample rate, or null if all paths fail
     */
    fun synthesize(
        tokenIds: LongArray,
        modulated: ModulatedVoice,
        signal: SignalMap,
        profile: VoiceProfile,
    ): SynthResult? {

        // Path 1: Kokoro with style sculpting (highest quality, most expressive)
        if (directOrtEnabled && directOrt.isKokoroReady) {
            val result = synthesizeKokoroSculpted(tokenIds, modulated, signal)
            if (result != null) return result
            Log.w(TAG, "Kokoro sculpted path failed, trying next")
        }

        // Path 2: Piper with scale mapping (good quality, different lever set)
        if (directOrtEnabled && directOrt.isPiperReady) {
            val result = synthesizePiperMapped(tokenIds, modulated, signal)
            if (result != null) return result
            Log.w(TAG, "Piper mapped path failed, trying next")
        }

        // Path 3: Existing SherpaEngine (speed-only control, proven stable)
        return synthesizeSherpaFallback(tokenIds, modulated)
    }

    // ─── Kokoro Path ────────────────────────────────────────────────────

    private fun synthesizeKokoroSculpted(
        tokenIds: LongArray,
        modulated: ModulatedVoice,
        signal: SignalMap,
    ): SynthResult? {
        return try {
            // 1. Get base style vector for current voice + utterance length
            val baseStyle = directOrt.getKokoroStyle(
                activeKokoroVoiceIndex,
                tokenIds.size
            ) ?: return null

            // 2. Sculpt the style vector based on emotional context
            val sculptedStyle = StyleSculptor.sculpt(
                baseStyle = baseStyle,
                modulated = modulated,
                signal = signal,
                secondaryPalette = secondaryPalette,
            )

            // 3. Run inference with the sculpted style
            val (pcm, sampleRate) = directOrt.synthesizeKokoro(
                inputIds = tokenIds,
                sculptedStyle = sculptedStyle,
                speed = modulated.speed,
            ) ?: return null

            SynthResult(
                pcm = pcm,
                sampleRate = sampleRate,
                engine = EngineType.KOKORO_SCULPTED,
            )
        } catch (e: Exception) {
            Log.e(TAG, "Kokoro sculpted synthesis error: ${e.message}", e)
            null
        }
    }

    // ─── Piper Path ─────────────────────────────────────────────────────

    private fun synthesizePiperMapped(
        tokenIds: LongArray,
        modulated: ModulatedVoice,
        signal: SignalMap,
    ): SynthResult? {
        return try {
            // 1. Map emotional parameters to Piper's generative scales
            val scales = ScaleMapper.mapScales(modulated, signal)

            // 2. Run inference with mapped scales
            // NOTE: Piper uses different phoneme IDs than Kokoro.
            // The tokenIds here need to be from eSpeak phonemization, not Kokoro's tokenizer.
            // In practice, you'd have two tokenization paths — one for each engine.
            val (pcm, sampleRate) = directOrt.synthesizePiper(
                phonemeIds = tokenIds,
                scales = scales,
                speakerId = activePiperSpeakerId,
            ) ?: return null

            SynthResult(
                pcm = pcm,
                sampleRate = sampleRate,
                engine = EngineType.PIPER_MAPPED,
            )
        } catch (e: Exception) {
            Log.e(TAG, "Piper mapped synthesis error: ${e.message}", e)
            null
        }
    }

    // ─── Sherpa Fallback ────────────────────────────────────────────────

    private fun synthesizeSherpaFallback(
        tokenIds: LongArray,
        modulated: ModulatedVoice,
    ): SynthResult? {
        // This calls the existing SherpaEngine path exactly as AudioPipeline does today.
        // Only speed is controllable here — everything else goes through DSP as before.
        return try {
            // The existing SherpaEngine.synthesize() takes text + speed, not token IDs.
            // So we'd need the original text here. In practice, AudioPipeline would
            // pass both text and tokenIds to synthesize().
            // For now, we return null to let AudioPipeline handle the sherpa path itself.
            Log.i(TAG, "Falling back to SherpaEngine (speed-only control)")
            null  // Signal AudioPipeline to use its existing sherpa path
        } catch (e: Exception) {
            Log.e(TAG, "Sherpa fallback error: ${e.message}", e)
            null
        }
    }

    // ─── Voice Management ───────────────────────────────────────────────

    /**
     * Set up the secondary voice palette for emotional blending.
     * Call this when the user changes their voice profile or secondary blend voice.
     *
     * The idea: if the primary voice is af_bella (warm, clear), setting
     * af_sky (warm, breathy) as secondary means emotional intensity
     * will blend toward breathier delivery at the synthesis level.
     */
    fun setSecondaryVoice(voiceName: String, voiceIndex: Int) {
        val allData = directOrt.getAllVoicesData() ?: return
        secondaryPalette = StyleSculptor.loadPalette(
            name = voiceName,
            allVoicesData = allData,
            voiceIndex = voiceIndex,
            numTokenLengths = directOrt.getTokensPerVoice(),
        )
        secondaryVoiceName = voiceName
        Log.i(TAG, "Secondary voice set to $voiceName for emotional blending")
    }

    // ─── Data Types ─────────────────────────────────────────────────────

    data class SynthResult(
        val pcm: FloatArray,
        val sampleRate: Int,
        val engine: EngineType,
    )

    enum class EngineType {
        KOKORO_SCULPTED,  // Direct ORT with style sculpting
        PIPER_MAPPED,     // Direct ORT with scale mapping
        SHERPA_KOKORO,    // Existing sherpa path (speed only)
        SHERPA_PIPER,     // Existing sherpa Piper fallback
        SYSTEM_TTS,       // Android system TTS
    }
}

// ─── INTEGRATION INTO AUDIOPIPELINE ─────────────────────────────────────
//
// In AudioPipeline.kt, where you currently call:
//
//   val (pcm, sampleRate) = sherpaEngine.synthesizeWithFallback(text, speed)
//
// Replace with:
//
//   val result = legoSynthesizer.synthesize(tokenIds, modulated, signal, profile)
//   if (result != null) {
//       val pcm = result.pcm
//       val sampleRate = result.sampleRate
//       // Continue with existing DSP chain...
//       // But now DSP handles LESS because sculpting/mapping already did the heavy lifting
//   } else {
//       // Fall through to existing SherpaEngine path (unchanged)
//       val (pcm, sampleRate) = sherpaEngine.synthesizeWithFallback(text, speed)
//   }
//
// The DSP chain still runs after synthesis — but now it handles only:
//   - Vocal fry (needs PhonicLandmarks, which needs actual PCM)
//   - Trailing off (trajectory-based)
//   - Pitch shift (until we find a pre-synthesis way to do it)
//   - Soft limiter (always needed)
//   - Inter-clip crossfade (always needed)
//
// Breathiness, jitter, intonation range, and energy are now handled
// pre-synthesis by StyleSculptor/ScaleMapper, so the DSP versions can
// be gradually dialed down or disabled.
// ────────────────────────────────────────────────────────────────────────
