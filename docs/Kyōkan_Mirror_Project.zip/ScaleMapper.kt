package com.kokoro.reader

import kotlin.math.abs

/**
 * ScaleMapper — Maps VoiceModulator output to Piper's generative parameters.
 *
 * Piper (VITS) exposes three scale inputs that control voice character at synthesis time:
 *   - noise_scale:  Controls decoder noise → breathiness/expressiveness (default 0.667)
 *   - length_scale: Controls phoneme duration → speaking speed (default 1.0)
 *   - noise_w:      Controls stochastic duration predictor → rhythm variation (default 0.8)
 *
 * These are NOT post-processing. They feed directly into the generative model.
 * Changing noise_scale makes the model GENERATE breathy audio, not add noise on top.
 */
object ScaleMapper {

    // Piper default scales
    private const val DEFAULT_NOISE_SCALE = 0.667f
    private const val DEFAULT_LENGTH_SCALE = 1.0f
    private const val DEFAULT_NOISE_W = 0.8f

    // Safety bounds — going outside these produces garbage audio
    private const val MIN_NOISE_SCALE = 0.1f    // very clean/robotic
    private const val MAX_NOISE_SCALE = 1.2f     // very breathy/expressive
    private const val MIN_LENGTH_SCALE = 0.5f    // 2x speed
    private const val MAX_LENGTH_SCALE = 2.0f     // 0.5x speed
    private const val MIN_NOISE_W = 0.1f          // very metronomic rhythm
    private const val MAX_NOISE_W = 1.5f          // very varied rhythm

    /**
     * Map ModulatedVoice parameters to Piper's three scale values.
     *
     * @param modulated The emotional modulation from VoiceModulator
     * @param signal The signal map from SignalExtractor
     * @return FloatArray of [noise_scale, length_scale, noise_w]
     */
    fun mapScales(modulated: ModulatedVoice, signal: SignalMap): FloatArray {
        val noiseScale = mapNoiseScale(modulated, signal)
        val lengthScale = mapLengthScale(modulated)
        val noiseW = mapNoiseW(modulated, signal)

        return floatArrayOf(
            noiseScale.guardNaN(DEFAULT_NOISE_SCALE).coerceIn(MIN_NOISE_SCALE, MAX_NOISE_SCALE),
            lengthScale.guardNaN(DEFAULT_LENGTH_SCALE).coerceIn(MIN_LENGTH_SCALE, MAX_LENGTH_SCALE),
            noiseW.guardNaN(DEFAULT_NOISE_W).coerceIn(MIN_NOISE_W, MAX_NOISE_W),
        )
    }

    /**
     * noise_scale → BREATHINESS + EXPRESSIVENESS
     *
     * This controls how much stochastic noise feeds into the decoder.
     * Higher = more natural variation, breathier, more expressive.
     * Lower = cleaner, more precise, more robotic.
     *
     * Maps from:
     *   - modulated.breath (0-100): primary driver
     *   - emotion blend: secondary influence
     *   - flood tier: more overwhelmed = slightly more breath
     */
    private fun mapNoiseScale(modulated: ModulatedVoice, signal: SignalMap): Float {
        var scale = DEFAULT_NOISE_SCALE

        // Breath parameter: 0-100 → noise_scale shift of ±0.3
        // Quadratic curve so low values are subtle
        val breathNorm = modulated.breath / 100f
        val breathShift = smoothCurve(breathNorm) * 0.4f - 0.1f  // range: -0.1 to +0.3
        scale += breathShift

        // Emotion blend influence
        when (signal.emotionBlend) {
            EmotionBlend.NERVOUS_EXCITEMENT -> scale += 0.05f   // slightly more expressive
            EmotionBlend.SUPPRESSED_TENSION -> scale -= 0.08f   // tighter, more controlled
            EmotionBlend.NOSTALGIC_WARMTH -> scale += 0.08f     // warmer, breathier
            EmotionBlend.RESIGNED_ACCEPTANCE -> scale -= 0.05f  // flatter
            EmotionBlend.WORRIED_AFFECTION -> scale += 0.03f    // slight warmth
            null -> {}
        }

        // Flood tier: overwhelmed → breathier (like being out of breath)
        when (signal.floodTier) {
            FloodTier.FLOODED -> scale += 0.04f
            FloodTier.OVERWHELMED -> scale += 0.08f
            else -> {}
        }

        return scale
    }

    /**
     * length_scale → SPEAKING SPEED
     *
     * This controls predicted phoneme durations.
     * Higher = slower speech (longer phonemes).
     * Lower = faster speech (shorter phonemes).
     *
     * NOTE: length_scale is inverted from the intuitive "speed" concept.
     * speed=1.2 in ModulatedVoice means "speak faster" → length_scale < 1.0
     *
     * Maps from:
     *   - modulated.speed: primary driver (direct mapping)
     */
    private fun mapLengthScale(modulated: ModulatedVoice): Float {
        // ModulatedVoice.speed is a multiplier: 1.0=normal, >1=faster, <1=slower
        // Piper length_scale is the inverse: 1.0=normal, >1=slower, <1=faster
        // Direct inversion with safety clamp
        return if (modulated.speed > 0.01f) {
            1f / modulated.speed
        } else {
            DEFAULT_LENGTH_SCALE
        }
    }

    /**
     * noise_w → RHYTHM VARIATION / NATURALNESS
     *
     * Controls the stochastic duration predictor's influence.
     * Higher = more natural rhythm with slight variations per phoneme.
     * Lower = more mechanical, metronomic timing.
     *
     * Maps from:
     *   - modulated.intonation: primary driver (wider intonation = more rhythm variation)
     *   - modulated.jitter: secondary (more jitter = more variation)
     *   - emotion blend: tertiary
     */
    private fun mapNoiseW(modulated: ModulatedVoice, signal: SignalMap): Float {
        var noiseW = DEFAULT_NOISE_W

        // Intonation multiplier: 1.0=normal, >1=wider, <1=flatter
        // Maps to noise_w shift: flatter intonation → more metronomic
        val intonationShift = (modulated.intonation - 1f) * 0.3f
        noiseW += intonationShift

        // Jitter adds rhythm variation (replaces DSP jitter for Piper)
        val jitterNorm = modulated.jitter / 100f
        noiseW += smoothCurve(jitterNorm) * 0.2f

        // Emotion overrides
        when (signal.emotionBlend) {
            EmotionBlend.NERVOUS_EXCITEMENT -> noiseW += 0.1f   // jittery timing
            EmotionBlend.SUPPRESSED_TENSION -> noiseW -= 0.15f  // controlled, steady
            EmotionBlend.NOSTALGIC_WARMTH -> noiseW += 0.05f    // gentle variation
            EmotionBlend.RESIGNED_ACCEPTANCE -> noiseW -= 0.1f  // monotone rhythm
            EmotionBlend.WORRIED_AFFECTION -> noiseW += 0.05f   // slight unsteadiness
            null -> {}
        }

        // Sarcasm → flatten rhythm (deliberate, measured delivery)
        if (signal.detectedSarcasm) {
            noiseW -= 0.1f
        }

        return noiseW
    }

    // ─── Utility ───────────────────────────────────────────────────────

    private fun smoothCurve(v: Float): Float = v * v

    private fun Float.guardNaN(default: Float): Float =
        if (this.isNaN() || this.isInfinite()) default else this
}
