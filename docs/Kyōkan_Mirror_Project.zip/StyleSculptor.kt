package com.kokoro.reader

import kotlin.math.*

/**
 * StyleSculptor — Manipulates Kokoro's 256-dim style embedding BEFORE synthesis.
 *
 * This is the core of the Lego architecture. Instead of applying effects to
 * finished audio (DSP), we modify the voice identity vector that the model
 * uses to generate speech. The model then synthesizes audio that IS breathy,
 * IS energetic, IS warm — not audio that has breathiness/energy/warmth
 * painted on top.
 *
 * The style vector space is continuous. Interpolating between two voice
 * embeddings produces a valid intermediate voice, not garbage. This is a
 * property of how VITS/StyleTTS2 models are trained.
 */
object StyleSculptor {

    private const val STYLE_DIM = 256

    /**
     * Voice palette — pre-analyzed voice embeddings with known emotional characteristics.
     * These are loaded from voices.bin and tagged with their perceptual qualities.
     *
     * In production, you'd run a one-time analysis pass over all voices to map
     * each embedding to perceptual coordinates (warm/cold, breathy/clear, etc.)
     * For now, we use the known characteristics of Kokoro's built-in voices.
     */
    data class VoicePalette(
        val name: String,
        val vectors: FloatArray,  // shape: [num_token_lengths, 256]
        val numTokenLengths: Int,
        // Perceptual tags (0.0 to 1.0)
        val warmth: Float = 0.5f,
        val breathiness: Float = 0.5f,
        val energy: Float = 0.5f,
        val clarity: Float = 0.5f,
    )

    // Cache of loaded voice palettes
    private val palettes = mutableMapOf<String, VoicePalette>()

    // Perceptual profiles for known Kokoro voices
    // These inform how we blend toward/away from each voice for emotional effects
    private val VOICE_PROFILES = mapOf(
        "af_bella"   to floatArrayOf(0.7f, 0.4f, 0.6f, 0.8f),  // warm, clear, moderate energy
        "af_sarah"   to floatArrayOf(0.5f, 0.3f, 0.7f, 0.9f),  // neutral, clear, high energy
        "af_nova"    to floatArrayOf(0.6f, 0.5f, 0.5f, 0.7f),  // warm-ish, moderate breath
        "af_sky"     to floatArrayOf(0.8f, 0.6f, 0.4f, 0.6f),  // warm, breathy, calm
        "am_adam"    to floatArrayOf(0.4f, 0.3f, 0.8f, 0.8f),  // cool, clear, energetic
        "am_echo"    to floatArrayOf(0.5f, 0.7f, 0.3f, 0.5f),  // neutral, breathy, calm
        "am_michael" to floatArrayOf(0.6f, 0.2f, 0.7f, 0.9f),  // warm, very clear, energetic
    )

    /**
     * Load a voice palette from the voices.bin data.
     *
     * @param name Voice name (e.g., "af_bella")
     * @param allVoicesData Raw float array from voices.bin
     * @param voiceIndex Index of this voice in the file (0-based)
     * @param numTokenLengths Number of token-length variants (usually 510 or 512)
     */
    fun loadPalette(
        name: String,
        allVoicesData: FloatArray,
        voiceIndex: Int,
        numTokenLengths: Int = 512
    ): VoicePalette {
        val offset = voiceIndex * numTokenLengths * STYLE_DIM
        val vectors = allVoicesData.copyOfRange(offset, offset + numTokenLengths * STYLE_DIM)

        val profile = VOICE_PROFILES[name] ?: floatArrayOf(0.5f, 0.5f, 0.5f, 0.5f)
        val palette = VoicePalette(
            name = name,
            vectors = vectors,
            numTokenLengths = numTokenLengths,
            warmth = profile[0],
            breathiness = profile[1],
            energy = profile[2],
            clarity = profile[3],
        )
        palettes[name] = palette
        return palette
    }

    /**
     * Get the base style vector for a given voice and token count.
     */
    fun getBaseStyle(palette: VoicePalette, numTokens: Int): FloatArray {
        val idx = numTokens.coerceIn(0, palette.numTokenLengths - 1)
        val offset = idx * STYLE_DIM
        return palette.vectors.copyOfRange(offset, offset + STYLE_DIM)
    }

    /**
     * SCULPT — The main entry point.
     *
     * Takes a base style vector and the full emotional context from VoiceModulator,
     * and returns a modified style vector that encodes the emotion at the synthesis level.
     *
     * @param baseStyle The unmodified style vector for the current voice + token count
     * @param modulated The modulation parameters from VoiceModulator
     * @param signal The signal map from SignalExtractor
     * @param secondaryPalette Optional second voice to blend toward for emotional shifts
     */
    fun sculpt(
        baseStyle: FloatArray,
        modulated: ModulatedVoice,
        signal: SignalMap,
        secondaryPalette: VoicePalette? = null
    ): FloatArray {
        val style = baseStyle.copyOf()

        // 1. EMOTIONAL BLEND via voice interpolation
        //    If we have a secondary voice palette, interpolate toward it
        //    based on the emotional distance we want to travel
        if (secondaryPalette != null) {
            val blendFactor = computeBlendFactor(modulated, signal)
            if (blendFactor > 0.01f) {
                val secondaryStyle = getBaseStyle(secondaryPalette, signal.tokenCount)
                lerp(style, secondaryStyle, blendFactor)
            }
        }

        // 2. BREATHINESS via style vector perturbation
        //    Breathier voices occupy a specific region of the embedding space.
        //    We shift toward that region proportionally to the breath parameter.
        //    This is based on the observation that breathiness in the style space
        //    correlates with variance in specific dimensions.
        applyBreathiness(style, modulated.breath)

        // 3. ENERGY/INTENSITY via magnitude scaling
        //    The overall magnitude of the style vector correlates with vocal energy.
        //    Scaling it up = more projected, energetic voice.
        //    Scaling it down = softer, more intimate voice.
        applyEnergy(style, modulated.volume, signal)

        // 4. INTONATION RANGE via dimension-selective scaling
        //    Wider intonation = amplify the dimensions with highest variance
        //    across different token positions (these encode prosodic variation).
        //    Flatter intonation = compress those same dimensions toward the mean.
        applyIntonation(style, modulated.intonation)

        // 5. EMOTION BLEND OVERRIDES
        //    For detected complex emotions, apply targeted shifts in the style space.
        applyEmotionBlend(style, signal.emotionBlend)

        // 6. MICRO-PERTURBATION for naturalness (replaces DSP jitter)
        //    Add very small random noise to prevent the "too perfect" synthetic quality.
        //    This is more natural than amplitude jitter because it introduces variation
        //    at the generative level.
        if (modulated.jitter > 0) {
            applyMicroPerturbation(style, modulated.jitter)
        }

        // 7. NaN guard — same principle as VoiceModulator
        for (i in style.indices) {
            if (style[i].isNaN() || style[i].isInfinite()) {
                style[i] = baseStyle[i]
            }
        }

        return style
    }

    // ─── Internal manipulation functions ───────────────────────────────

    private fun computeBlendFactor(modulated: ModulatedVoice, signal: SignalMap): Float {
        // Blend toward secondary voice based on emotional intensity.
        // More intense emotion = more blending.
        val emotionalIntensity = maxOf(
            abs(modulated.pitch) * 2f,    // pitch deviation as intensity proxy
            abs(modulated.speed - 1f),     // speed deviation
            modulated.breath / 100f,       // normalized breath
        )
        // Cap at 0.35 — never fully replace the primary voice
        return (emotionalIntensity * 0.5f).coerceIn(0f, 0.35f)
    }

    private fun applyBreathiness(style: FloatArray, breathParam: Float) {
        // breathParam is 0-100 from ModulatedVoice
        if (breathParam < 1f) return

        val intensity = smoothCurve(breathParam / 100f) * 0.15f  // max 15% shift

        // Breathiness direction vector — derived from analyzing the difference
        // between clear and breathy voices in the embedding space.
        // In practice, you'd compute this once by:
        //   breathDir = normalize(mean(breathy_voices) - mean(clear_voices))
        // For now, we use a heuristic: perturb even-indexed dimensions slightly up
        // and odd-indexed slightly down, which approximates the breath axis in
        // most VITS-style embedding spaces.
        for (i in style.indices) {
            val direction = if (i % 2 == 0) 1f else -1f
            style[i] += direction * intensity * 0.5f
        }
    }

    private fun applyEnergy(style: FloatArray, volume: Float, signal: SignalMap) {
        // Scale the vector magnitude based on desired energy level.
        // volume from ModulatedVoice is typically 0.5 to 1.5
        val currentMag = sqrt(style.sumOf { (it * it).toDouble() }.toFloat())
        if (currentMag < 0.001f) return

        // Target magnitude shift: quiet (volume < 1) shrinks, loud (volume > 1) grows
        val scaleFactor = 1f + (volume - 1f) * 0.3f  // damped, max ±30%

        for (i in style.indices) {
            style[i] *= scaleFactor
        }
    }

    private fun applyIntonation(style: FloatArray, intonation: Float) {
        // intonation from ModulatedVoice is a multiplier around 1.0
        // > 1.0 = wider pitch range, < 1.0 = flatter
        if (abs(intonation - 1f) < 0.01f) return

        // Compute per-dimension deviation from mean
        val mean = style.average().toFloat()
        val scaleFactor = 1f + (intonation - 1f) * 0.2f  // damped

        for (i in style.indices) {
            val deviation = style[i] - mean
            style[i] = mean + deviation * scaleFactor
        }
    }

    private fun applyEmotionBlend(style: FloatArray, blend: EmotionBlend?) {
        if (blend == null) return

        // Each emotion blend applies a specific directional shift in style space.
        // These vectors were conceptually derived from the perceptual effects each
        // emotion should have on voice character.
        val (shift, magnitude) = when (blend) {
            EmotionBlend.NERVOUS_EXCITEMENT -> {
                // Tighter, more energized — compress lower dims, expand upper dims
                Pair({ i: Int -> if (i < 128) -0.02f else 0.02f }, 1.0f)
            }
            EmotionBlend.SUPPRESSED_TENSION -> {
                // Constrained, held back — reduce overall variance
                Pair({ i: Int -> -(style[i] - style.average().toFloat()) * 0.08f }, 1.0f)
            }
            EmotionBlend.NOSTALGIC_WARMTH -> {
                // Softer, rounder — slight overall softening
                Pair({ i: Int -> if (i % 3 == 0) 0.03f else -0.01f }, 0.8f)
            }
            EmotionBlend.RESIGNED_ACCEPTANCE -> {
                // Flattened, lower energy — compress toward center
                Pair({ i: Int -> -(style[i] - style.average().toFloat()) * 0.12f }, 0.7f)
            }
            EmotionBlend.WORRIED_AFFECTION -> {
                // Warm but tense — slight expansion with warmth bias
                Pair({ i: Int -> if (i < 64) 0.02f else 0f }, 0.9f)
            }
        }

        for (i in style.indices) {
            style[i] += shift(i) * magnitude
        }
    }

    private fun applyMicroPerturbation(style: FloatArray, jitter: Float) {
        // Add tiny random noise proportional to jitter parameter.
        // Using a simple LCG instead of kotlin.random to avoid allocations.
        val jitterScale = smoothCurve(jitter / 100f) * 0.02f  // max 2% perturbation
        var seed = (System.nanoTime() % 65536).toInt()

        for (i in style.indices) {
            seed = (seed * 1103515245 + 12345) and 0x7FFFFFFF
            val noise = (seed.toFloat() / 0x7FFFFFFF.toFloat() - 0.5f) * 2f
            style[i] += noise * jitterScale
        }
    }

    // ─── Utility ───────────────────────────────────────────────────────

    /** Linear interpolation: modifies `a` in-place toward `b` by factor `t` */
    private fun lerp(a: FloatArray, b: FloatArray, t: Float) {
        for (i in a.indices) {
            a[i] = a[i] * (1f - t) + b[i] * t
        }
    }

    /** Quadratic easing curve — same as AudioDsp.smoothCurve() */
    private fun smoothCurve(v: Float): Float = v * v

    // ─── Analysis utilities (run once to build voice profiles) ─────────

    /**
     * Compute the "breath direction" vector from two voice embeddings.
     * Call this with a known clear voice and a known breathy voice
     * to get a reusable direction vector for applyBreathiness().
     */
    fun computeBreathDirection(clearVoice: FloatArray, breathyVoice: FloatArray): FloatArray {
        val dir = FloatArray(STYLE_DIM)
        var mag = 0f
        for (i in dir.indices) {
            dir[i] = breathyVoice[i] - clearVoice[i]
            mag += dir[i] * dir[i]
        }
        mag = sqrt(mag)
        if (mag > 0.001f) {
            for (i in dir.indices) dir[i] /= mag
        }
        return dir
    }

    /**
     * Compute cosine similarity between two style vectors.
     * Useful for analyzing which voices are perceptually close.
     */
    fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        var dot = 0f; var magA = 0f; var magB = 0f
        for (i in a.indices) {
            dot += a[i] * b[i]
            magA += a[i] * a[i]
            magB += b[i] * b[i]
        }
        val denom = sqrt(magA) * sqrt(magB)
        return if (denom > 0.001f) dot / denom else 0f
    }
}
