#!/usr/bin/env python3
"""
Kyōkan ONNX Graph Inspector
============================
Run this in GitHub Codespaces to dump every tensor from your Kokoro and Piper models.
This is your Lego parts catalog — you can't build without knowing what pieces you have.

Usage:
    pip install onnx onnxruntime numpy
    python inspect_graph.py path/to/kokoro-v1.0.onnx
    python inspect_graph.py path/to/en_US-amy-low.onnx
    python inspect_graph.py path/to/kokoro-v1.0.onnx path/to/piper-voice.onnx --compare
"""

import sys
import json
import argparse
from pathlib import Path

import onnx
from onnx import numpy_helper, TensorProto
import numpy as np

# Map ONNX dtype enum to readable names
DTYPE_MAP = {
    TensorProto.FLOAT: "float32",
    TensorProto.UINT8: "uint8",
    TensorProto.INT8: "int8",
    TensorProto.UINT16: "uint16",
    TensorProto.INT16: "int16",
    TensorProto.INT32: "int32",
    TensorProto.INT64: "int64",
    TensorProto.STRING: "string",
    TensorProto.BOOL: "bool",
    TensorProto.FLOAT16: "float16",
    TensorProto.DOUBLE: "float64",
    TensorProto.UINT32: "uint32",
    TensorProto.UINT64: "uint64",
    TensorProto.COMPLEX64: "complex64",
    TensorProto.COMPLEX128: "complex128",
    TensorProto.BFLOAT16: "bfloat16",
}


def get_shape_str(shape):
    """Convert ONNX shape to readable string."""
    dims = []
    for d in shape.dim:
        if d.dim_param:
            dims.append(d.dim_param)  # dynamic dimension name
        elif d.dim_value > 0:
            dims.append(str(d.dim_value))
        else:
            dims.append("?")
    return f"[{', '.join(dims)}]"


def inspect_model(model_path: str) -> dict:
    """Load an ONNX model and extract all tensor information."""
    print(f"\n{'='*70}")
    print(f"  INSPECTING: {Path(model_path).name}")
    print(f"  Size: {Path(model_path).stat().st_size / (1024*1024):.1f} MB")
    print(f"{'='*70}\n")

    model = onnx.load(model_path)
    graph = model.graph

    result = {
        "file": str(model_path),
        "size_mb": round(Path(model_path).stat().st_size / (1024*1024), 1),
        "opset": [op.version for op in model.opset_import],
        "inputs": [],
        "outputs": [],
        "metadata": {},
        "node_count": len(graph.node),
        "op_types": {},
        "initializer_count": len(graph.initializer),
    }

    # Metadata
    for prop in model.metadata_props:
        result["metadata"][prop.key] = prop.value
    if result["metadata"]:
        print("METADATA:")
        for k, v in result["metadata"].items():
            print(f"  {k}: {v}")
        print()

    # Inputs
    print("INPUTS (what you can manipulate):")
    print("-" * 50)
    for inp in graph.input:
        # Skip initializers (weights) that appear as inputs
        init_names = {init.name for init in graph.initializer}
        if inp.name in init_names:
            continue

        tensor_type = inp.type.tensor_type
        dtype = DTYPE_MAP.get(tensor_type.elem_type, f"unknown({tensor_type.elem_type})")
        shape = get_shape_str(tensor_type.shape)

        info = {"name": inp.name, "dtype": dtype, "shape": shape}
        result["inputs"].append(info)
        print(f"  {inp.name:20s}  {dtype:10s}  {shape}")

    print()

    # Outputs
    print("OUTPUTS:")
    print("-" * 50)
    for out in graph.output:
        tensor_type = out.type.tensor_type
        dtype = DTYPE_MAP.get(tensor_type.elem_type, f"unknown({tensor_type.elem_type})")
        shape = get_shape_str(tensor_type.shape)

        info = {"name": out.name, "dtype": dtype, "shape": shape}
        result["outputs"].append(info)
        print(f"  {out.name:20s}  {dtype:10s}  {shape}")

    print()

    # Op type histogram (shows what operations the model uses)
    for node in graph.node:
        result["op_types"][node.op_type] = result["op_types"].get(node.op_type, 0) + 1

    print(f"GRAPH STATS:")
    print(f"  Total nodes: {result['node_count']}")
    print(f"  Initializers (weights): {result['initializer_count']}")
    print(f"  Opset versions: {result['opset']}")
    print()

    # Top 15 op types
    sorted_ops = sorted(result["op_types"].items(), key=lambda x: -x[1])[:15]
    print("TOP OPERATIONS:")
    for op, count in sorted_ops:
        print(f"  {op:25s}  {count:4d}")
    print()

    # Look for interesting internal nodes that might be split points
    print("POTENTIAL SPLIT POINTS (named nodes with recognizable patterns):")
    print("-" * 50)
    split_keywords = [
        "encoder", "decoder", "vocoder", "duration", "flow",
        "posterior", "prior", "generator", "discriminator",
        "text_enc", "dec", "dp", "sdp", "hifi", "istft",
        "style", "embed", "prosody", "mel", "spectrogram"
    ]
    found_splits = []
    for node in graph.node:
        name_lower = (node.name or "").lower()
        for kw in split_keywords:
            if kw in name_lower:
                found_splits.append({
                    "name": node.name,
                    "op": node.op_type,
                    "inputs": list(node.input[:3]),  # first 3
                    "outputs": list(node.output[:2]),
                })
                break

    if found_splits:
        # Deduplicate by prefix
        seen_prefixes = set()
        for s in found_splits:
            prefix = s["name"].split("/")[0] if "/" in s["name"] else s["name"]
            if prefix not in seen_prefixes:
                seen_prefixes.add(prefix)
                print(f"  {s['name'][:60]:60s}  [{s['op']}]")
        if len(found_splits) > 20:
            print(f"  ... and {len(found_splits) - 20} more")
    else:
        print("  (no recognizable split-point names found)")
        print("  This is normal for optimized/exported models.")
        print("  The inputs/outputs above are your manipulation points.")

    print()

    # Check for sub-graphs (If/Loop nodes)
    subgraph_nodes = [n for n in graph.node if n.op_type in ("If", "Loop", "Scan")]
    if subgraph_nodes:
        print(f"SUB-GRAPHS: Found {len(subgraph_nodes)} nodes with sub-graphs")
        for n in subgraph_nodes:
            print(f"  {n.name} ({n.op_type})")
        print()

    return result


def compare_models(result_a: dict, result_b: dict):
    """Compare two models for Lego compatibility."""
    print(f"\n{'='*70}")
    print("  COMPATIBILITY ANALYSIS")
    print(f"{'='*70}\n")

    print("INPUT COMPARISON:")
    print(f"  {'Model A':30s} {'Model B':30s}")
    print(f"  {'-'*30} {'-'*30}")

    max_inputs = max(len(result_a["inputs"]), len(result_b["inputs"]))
    for i in range(max_inputs):
        a = result_a["inputs"][i] if i < len(result_a["inputs"]) else {"name": "-", "dtype": "-", "shape": "-"}
        b = result_b["inputs"][i] if i < len(result_b["inputs"]) else {"name": "-", "dtype": "-", "shape": "-"}
        print(f"  {a['name']:12s} {a['dtype']:8s} {a['shape']:10s} {b['name']:12s} {b['dtype']:8s} {b['shape']:10s}")

    print()
    print("OUTPUT COMPARISON:")
    for i in range(max(len(result_a["outputs"]), len(result_b["outputs"]))):
        a = result_a["outputs"][i] if i < len(result_a["outputs"]) else {"name": "-", "dtype": "-", "shape": "-"}
        b = result_b["outputs"][i] if i < len(result_b["outputs"]) else {"name": "-", "dtype": "-", "shape": "-"}
        print(f"  {a['name']:12s} {a['dtype']:8s} {a['shape']:10s} {b['name']:12s} {b['dtype']:8s} {b['shape']:10s}")

    print()
    print("SHARED OPS:")
    shared = set(result_a["op_types"].keys()) & set(result_b["op_types"].keys())
    only_a = set(result_a["op_types"].keys()) - set(result_b["op_types"].keys())
    only_b = set(result_b["op_types"].keys()) - set(result_a["op_types"].keys())
    print(f"  Both use: {len(shared)} op types")
    if only_a:
        print(f"  Only in A: {', '.join(sorted(only_a)[:10])}")
    if only_b:
        print(f"  Only in B: {', '.join(sorted(only_b)[:10])}")

    print()
    print("KEY OBSERVATIONS FOR LEGO BUILD:")
    print("-" * 50)

    # Check if both produce audio output
    a_out_shapes = [o["shape"] for o in result_a["outputs"]]
    b_out_shapes = [o["shape"] for o in result_b["outputs"]]
    print(f"  Output shapes: A={a_out_shapes}, B={b_out_shapes}")

    # Style vector presence
    a_has_style = any("256" in str(i["shape"]) for i in result_a["inputs"])
    b_has_style = any("256" in str(i["shape"]) for i in result_b["inputs"])
    if a_has_style:
        print("  ✓ Model A has 256-dim style input (manipulable voice identity)")
    if b_has_style:
        print("  ✓ Model B has 256-dim style input (manipulable voice identity)")

    # Scales presence
    a_has_scales = any("scale" in i["name"].lower() for i in result_a["inputs"])
    b_has_scales = any("scale" in i["name"].lower() for i in result_b["inputs"])
    if a_has_scales:
        print("  ✓ Model A has scale inputs (noise/length/noise_w)")
    if b_has_scales:
        print("  ✓ Model B has scale inputs (noise/length/noise_w)")


def inspect_voices_bin(voices_path: str):
    """Inspect a Kokoro voices.bin file to understand the embedding structure."""
    print(f"\n{'='*70}")
    print(f"  INSPECTING VOICES: {Path(voices_path).name}")
    print(f"{'='*70}\n")

    data = np.fromfile(voices_path, dtype=np.float32)
    print(f"Total floats: {len(data)}")
    print(f"File size: {Path(voices_path).stat().st_size / 1024:.1f} KB")

    # Each voice has shape [-1, 1, 256] where -1 = number of token-length variants
    style_dim = 256
    total_vectors = len(data) // style_dim
    print(f"Total style vectors (at dim=256): {total_vectors}")
    print(f"If 510 variants per voice: {total_vectors / 510:.1f} voices")
    print(f"If 512 variants per voice: {total_vectors / 512:.1f} voices")

    # Show statistics of the embedding space
    reshaped = data.reshape(-1, style_dim)
    print(f"\nEmbedding space statistics:")
    print(f"  Mean:   {reshaped.mean():.4f}")
    print(f"  Std:    {reshaped.std():.4f}")
    print(f"  Min:    {reshaped.min():.4f}")
    print(f"  Max:    {reshaped.max():.4f}")

    # Check dimensionwise variance (which dims carry most info)
    dim_var = reshaped.var(axis=0)
    top_dims = np.argsort(dim_var)[-10:][::-1]
    print(f"\n  Top 10 most variable dimensions: {top_dims.tolist()}")
    print(f"  Their variances: {dim_var[top_dims].tolist()}")

    # Check similarity between first few voices (if multiple)
    if total_vectors >= 1024:
        # Assume 512 variants per voice, compare voice 0 vs voice 1
        v0 = reshaped[256]  # middle token-length for voice 0
        v1 = reshaped[512 + 256]  # middle for voice 1
        cosine = np.dot(v0, v1) / (np.linalg.norm(v0) * np.linalg.norm(v1))
        l2 = np.linalg.norm(v0 - v1)
        print(f"\n  Voice 0 vs Voice 1 (at token_len=256):")
        print(f"    Cosine similarity: {cosine:.4f}")
        print(f"    L2 distance: {l2:.4f}")
        print(f"    → {'Similar voices' if cosine > 0.9 else 'Distinct voices'}")


def main():
    parser = argparse.ArgumentParser(description="Kyōkan ONNX Graph Inspector")
    parser.add_argument("models", nargs="+", help="Path(s) to ONNX model files or voices.bin")
    parser.add_argument("--compare", action="store_true", help="Compare two models for compatibility")
    parser.add_argument("--json", help="Save results to JSON file")
    args = parser.parse_args()

    results = []
    for path in args.models:
        if path.endswith(".bin"):
            inspect_voices_bin(path)
        else:
            result = inspect_model(path)
            results.append(result)

    if args.compare and len(results) >= 2:
        compare_models(results[0], results[1])

    if args.json:
        with open(args.json, "w") as f:
            json.dump(results, f, indent=2)
        print(f"\nResults saved to {args.json}")

    if results:
        print(f"\n{'='*70}")
        print("  NEXT STEPS")
        print(f"{'='*70}")
        print()
        print("  1. Run this on your actual model files in Codespaces:")
        print("     python inspect_graph.py kokoro-v1.0.onnx en_US-amy-low.onnx --compare")
        print()
        print("  2. Also inspect your voices.bin:")
        print("     python inspect_graph.py voices-v1.0.bin")
        print()
        print("  3. The output will confirm exact tensor names and shapes")
        print("     needed for StyleSculptor.kt and ScaleMapper.kt")


if __name__ == "__main__":
    main()
